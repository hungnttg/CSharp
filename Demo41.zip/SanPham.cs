using System;
class SanPham {
    //Dinh nghia thuoc tinh
    private String TenSanPham;
    private double DonGia;
    private double GiamGia;
    //Dinh ngia phuong thuc
    public double getThueNhapKhau()
    {
        return 0.1*this.DonGia;
    }
    public double getThanhTien()
    {
        return this.DonGia*1+this.getThueNhapKhau()-this.GiamGia;
    }
    public void nhap()
    {
        Console.WriteLine("Nhap San pham");
        Console.WriteLine("TenSP:");
        //luu gia tri nhap vao thuoc tinh TenSanPham
        this.TenSanPham = Convert.ToString(Console.ReadLine());
        Console.WriteLine("DonGia: ");
        //luu gia tri nhap vao thuoc tinh DonGia
        this.DonGia = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("GiamGia:");
        //luu gia tri nhap vao thuoc tinh GiamGia
        this.GiamGia = Convert.ToDouble(Console.ReadLine());
    }
    public void xuat()
    {
        Console.WriteLine("Xuat thong tin san pham");
        Console.WriteLine("Ten SP: {0}",this.TenSanPham);
        Console.WriteLine("Don gia: {0}",this.DonGia);
        Console.WriteLine("Giam Gia: {0}",this.GiamGia);
        Console.WriteLine("Thanh tien: {0}",this.getThanhTien());
    }
}
