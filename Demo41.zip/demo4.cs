using System;
class HelloWorld {
  static void Main() {
    SanPham s = new SanPham();//tao doi tuong moi
    s.nhap();//goi phuong thuc nhap
    s.xuat();//goi phuong thuc xuat
  }
}
